import{l as o,a as r}from"../chunks/P8w9H7Hj.js";export{o as load_css,r as start};
