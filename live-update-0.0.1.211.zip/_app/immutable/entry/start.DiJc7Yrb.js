import{l as o,a as r}from"../chunks/Bb56y8__.js";export{o as load_css,r as start};
