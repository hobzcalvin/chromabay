
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="cf03d6fa-6389-539d-9ee9-fbae3f9a0c26")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_68jgje)==null?void 0:s.base)??"";var e;const t=((e=globalThis.__sveltekit_68jgje)==null?void 0:e.assets)??a;export{t as a,a as b};
//# sourceMappingURL=CDH21Jl5.js.map

//# debugId=cf03d6fa-6389-539d-9ee9-fbae3f9a0c26
