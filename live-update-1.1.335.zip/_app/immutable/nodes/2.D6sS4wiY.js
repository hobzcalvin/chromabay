
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="62b34bfc-78ce-574a-ba99-8c0aecae46dd")}catch(e){}}();
import{f as a,a as m}from"../chunks/Rohqeugo.js";import{i as t}from"../chunks/D4AgwrkV.js";import{o as i}from"../chunks/DDVIaiys.js";import{p as s,a as e}from"../chunks/DMuXAWdp.js";import{g as f}from"../chunks/Du8e3I0-.js";import{b as n}from"../chunks/CDH21Jl5.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.D6sS4wiY.js.map

//# debugId=62b34bfc-78ce-574a-ba99-8c0aecae46dd
