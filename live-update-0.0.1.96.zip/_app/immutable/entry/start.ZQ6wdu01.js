import{l as o,a as r}from"../chunks/BJnYJ0QU.js";export{o as load_css,r as start};
