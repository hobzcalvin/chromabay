import{l as o,a as r}from"../chunks/CXIc7Otd.js";export{o as load_css,r as start};
