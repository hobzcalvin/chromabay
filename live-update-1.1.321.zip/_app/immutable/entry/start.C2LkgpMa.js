
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="9c8e85fd-227c-5c9c-9902-5796389444c4")}catch(e){}}();
import{l as o,a as r}from"../chunks/DTV7UM9s.js";export{o as load_css,r as start};
//# sourceMappingURL=start.C2LkgpMa.js.map

//# debugId=9c8e85fd-227c-5c9c-9902-5796389444c4
