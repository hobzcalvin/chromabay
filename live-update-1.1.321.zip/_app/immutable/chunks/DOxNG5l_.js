
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="a1d760e2-b22d-517d-a64f-462de6caefc2")}catch(e){}}();
import{s as r}from"./DTV7UM9s.js";const e=()=>{const s=r;return{page:{subscribe:s.page.subscribe},navigating:{subscribe:s.navigating.subscribe},updated:s.updated}},a={subscribe(s){return e().page.subscribe(s)}},i={subscribe(s){return e().navigating.subscribe(s)}};export{i as n,a as p};
//# sourceMappingURL=DOxNG5l_.js.map

//# debugId=a1d760e2-b22d-517d-a64f-462de6caefc2
