
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="db195df9-d2d2-5113-bf72-2ca5ff511262")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_1g2vy5a)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1g2vy5a)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=fs4FFE1b.js.map

//# debugId=db195df9-d2d2-5113-bf72-2ca5ff511262
