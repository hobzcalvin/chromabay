
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0ac8d9a0-0de1-591f-9636-00bdf153c91a")}catch(e){}}();
import{f as a,a as m}from"../chunks/YSQa8gwn.js";import{i as t}from"../chunks/B4ueUsda.js";import{o as i}from"../chunks/iIm-hiKV.js";import{p as s,a as e}from"../chunks/DhkHA5kK.js";import{g as f}from"../chunks/DTV7UM9s.js";import{b as n}from"../chunks/fs4FFE1b.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.Dh86DUOX.js.map

//# debugId=0ac8d9a0-0de1-591f-9636-00bdf153c91a
