
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="4abf4741-a01e-5132-ad55-956079d88c2a")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_1dn7rq1)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1dn7rq1)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=Bs997L_d.js.map

//# debugId=4abf4741-a01e-5132-ad55-956079d88c2a
