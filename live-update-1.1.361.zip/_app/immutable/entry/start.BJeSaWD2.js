
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="edeb92b4-4543-5f41-a36c-6cdc44721840")}catch(e){}}();
import{l as o,a as r}from"../chunks/2o80lxKR.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BJeSaWD2.js.map

//# debugId=edeb92b4-4543-5f41-a36c-6cdc44721840
