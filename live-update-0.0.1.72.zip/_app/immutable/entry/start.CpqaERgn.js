import{l as o,a as r}from"../chunks/BK_DdKoR.js";export{o as load_css,r as start};
