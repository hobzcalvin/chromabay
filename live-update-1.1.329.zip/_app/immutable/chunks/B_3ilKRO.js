
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5ff44522-465b-5bb4-9802-ba282de8197f")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_17mr6da)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_17mr6da)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=B_3ilKRO.js.map

//# debugId=5ff44522-465b-5bb4-9802-ba282de8197f
