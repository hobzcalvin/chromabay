
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2c606c2f-fde3-500e-8a4d-1d86b497faf1")}catch(e){}}();
import{f as a,a as m}from"../chunks/Rohqeugo.js";import{i as t}from"../chunks/D4AgwrkV.js";import{o as i}from"../chunks/DDVIaiys.js";import{p as s,a as e}from"../chunks/DMuXAWdp.js";import{g as f}from"../chunks/BhO9ljte.js";import{b as n}from"../chunks/B_3ilKRO.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.l-sTQTdD.js.map

//# debugId=2c606c2f-fde3-500e-8a4d-1d86b497faf1
