import{l as o,a as r}from"../chunks/BlI_GERT.js";export{o as load_css,r as start};
