import{l as o,a as r}from"../chunks/CQ9CDqQI.js";export{o as load_css,r as start};
