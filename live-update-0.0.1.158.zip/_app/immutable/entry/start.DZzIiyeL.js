import{l as o,a as r}from"../chunks/6IZV3XRZ.js";export{o as load_css,r as start};
