
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e4c237fb-59f7-523f-a4c1-d4c3bd9871bc")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/CUcCykXD.js";import{o as a}from"../chunks/CHT_Wnc9.js";import{p as r,a as p}from"../chunks/Cd1DiQE4.js";import{g as s}from"../chunks/kjDAPYAP.js";import{b as i}from"../chunks/v3uz5LlD.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.B0_j6r44.js.map

//# debugId=e4c237fb-59f7-523f-a4c1-d4c3bd9871bc
