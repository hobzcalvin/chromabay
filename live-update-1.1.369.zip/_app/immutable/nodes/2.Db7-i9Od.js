
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5e030ab5-f215-5093-8f29-cf71765ae9c0")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CUcCykXD.js";import{o as m}from"../chunks/CHT_Wnc9.js";import{p as t,a as i}from"../chunks/Cd1DiQE4.js";import{f as s,a as e}from"../chunks/CR6uqQw-.js";import{g as f}from"../chunks/kjDAPYAP.js";import{b as n}from"../chunks/v3uz5LlD.js";var c=s("<p>Redirecting...</p>");function _(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),a();var r=c();e(o,r),i()}export{_ as component};
//# sourceMappingURL=2.Db7-i9Od.js.map

//# debugId=5e030ab5-f215-5093-8f29-cf71765ae9c0
