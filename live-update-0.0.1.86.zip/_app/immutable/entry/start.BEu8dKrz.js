import{l as o,a as r}from"../chunks/C2nE1xB8.js";export{o as load_css,r as start};
