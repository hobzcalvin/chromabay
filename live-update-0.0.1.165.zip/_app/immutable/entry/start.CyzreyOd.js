import{l as o,a as r}from"../chunks/D0M-4VTm.js";export{o as load_css,r as start};
