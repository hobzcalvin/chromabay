
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="36eedd71-7187-58f0-a614-ad84b37a0a1a")}catch(e){}}();
import{l as o,a as r}from"../chunks/BI5cHpsa.js";export{o as load_css,r as start};
//# sourceMappingURL=start.D4pjwxk1.js.map

//# debugId=36eedd71-7187-58f0-a614-ad84b37a0a1a
