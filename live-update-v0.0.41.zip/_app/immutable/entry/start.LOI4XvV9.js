import{l as o,a as r}from"../chunks/o_gaoJ5D.js";export{o as load_css,r as start};
