import{l as o,a as r}from"../chunks/C_oVIiBW.js";export{o as load_css,r as start};
