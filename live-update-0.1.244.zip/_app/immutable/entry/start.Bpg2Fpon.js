import{l as o,a as r}from"../chunks/dgnbyw8a.js";export{o as load_css,r as start};
