import{l as o,a as r}from"../chunks/B1wT6jY1.js";export{o as load_css,r as start};
