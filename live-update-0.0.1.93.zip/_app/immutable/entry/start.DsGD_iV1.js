import{l as o,a as r}from"../chunks/D6KdF4sR.js";export{o as load_css,r as start};
