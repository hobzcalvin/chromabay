
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="720e53d2-8c9d-56a9-94ac-2ce5cde90d9a")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/CG61vAxM.js";import{o as a}from"../chunks/DN4X5Wsx.js";import{p as r,a as p}from"../chunks/BkFBD7gE.js";import{g as s}from"../chunks/D4a24HDm.js";import{b as i}from"../chunks/DLc5WnDa.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.C1gZohuq.js.map

//# debugId=720e53d2-8c9d-56a9-94ac-2ce5cde90d9a
