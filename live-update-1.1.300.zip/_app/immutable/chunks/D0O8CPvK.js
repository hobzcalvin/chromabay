
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="78ac45f0-45f2-5332-be38-fbe601672731")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_1pjp7ll)==null?void 0:s.base)??"";var l;const e=((l=globalThis.__sveltekit_1pjp7ll)==null?void 0:l.assets)??a;export{e as a,a as b};
//# sourceMappingURL=D0O8CPvK.js.map

//# debugId=78ac45f0-45f2-5332-be38-fbe601672731
