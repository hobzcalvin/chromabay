
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5c81ae36-dd58-5a2c-8270-2fd29254ae1a")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_23thqz)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_23thqz)==null?void 0:t.assets)??a;export{e as a,a as b};
//# sourceMappingURL=B0r3lo3B.js.map

//# debugId=5c81ae36-dd58-5a2c-8270-2fd29254ae1a
