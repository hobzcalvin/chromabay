
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f52bbf7c-856f-55cf-b079-c6f38be726d8")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CHHvBerd.js";import{p as t,o as r,a as s}from"../chunks/HeQaF-Yi.js";import{g as p}from"../chunks/hPOhttLO.js";import{b as i}from"../chunks/B0r3lo3B.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.DPB84jbH.js.map

//# debugId=f52bbf7c-856f-55cf-b079-c6f38be726d8
