
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d7eec92c-0b8b-525f-8688-62f3aee41805")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CUcCykXD.js";import{o as m}from"../chunks/CHT_Wnc9.js";import{p as t,a as i}from"../chunks/Cd1DiQE4.js";import{f as s,a as e}from"../chunks/CR6uqQw-.js";import{g as f}from"../chunks/Do4kbaVw.js";import{b as n}from"../chunks/Dj3AQ8EE.js";var c=s("<p>Redirecting...</p>");function _(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),a();var r=c();e(o,r),i()}export{_ as component};
//# sourceMappingURL=2.DXfv803a.js.map

//# debugId=d7eec92c-0b8b-525f-8688-62f3aee41805
