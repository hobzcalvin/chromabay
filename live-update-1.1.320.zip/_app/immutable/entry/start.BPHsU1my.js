
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="55338a57-2257-5367-a902-bedf1c725f0a")}catch(e){}}();
import{l as o,a as r}from"../chunks/DGxwqCy6.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BPHsU1my.js.map

//# debugId=55338a57-2257-5367-a902-bedf1c725f0a
