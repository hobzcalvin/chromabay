
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="aec40040-121a-57bf-b162-92379e3097c3")}catch(e){}}();
import{f as a,a as m}from"../chunks/YSQa8gwn.js";import{i as t}from"../chunks/B4ueUsda.js";import{o as i}from"../chunks/iIm-hiKV.js";import{p as s,a as e}from"../chunks/DhkHA5kK.js";import{g as f}from"../chunks/DGxwqCy6.js";import{b as n}from"../chunks/CDo13e3-.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.BwQljEQ7.js.map

//# debugId=aec40040-121a-57bf-b162-92379e3097c3
