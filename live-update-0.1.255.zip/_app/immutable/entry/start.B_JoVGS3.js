import{l as o,a as r}from"../chunks/l10Vu3Ha.js";export{o as load_css,r as start};
