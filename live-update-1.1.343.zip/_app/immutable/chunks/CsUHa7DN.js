
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6c9d768e-3def-5fb0-b0ff-15871af8fa12")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_cvguze)==null?void 0:s.base)??"";var e;const t=((e=globalThis.__sveltekit_cvguze)==null?void 0:e.assets)??a;export{t as a,a as b};
//# sourceMappingURL=CsUHa7DN.js.map

//# debugId=6c9d768e-3def-5fb0-b0ff-15871af8fa12
