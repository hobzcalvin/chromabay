import{l as o,a as r}from"../chunks/Bm70byvD.js";export{o as load_css,r as start};
