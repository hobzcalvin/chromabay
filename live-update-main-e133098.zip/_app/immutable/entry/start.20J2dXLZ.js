import{l as o,a as r}from"../chunks/nfsI1xE6.js";export{o as load_css,r as start};
