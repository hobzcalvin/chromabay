import{_ as m}from"../chunks/DcQmJx6I.js";export{m as component};
