import{l as o,a as r}from"../chunks/D8KDov7I.js";export{o as load_css,r as start};
