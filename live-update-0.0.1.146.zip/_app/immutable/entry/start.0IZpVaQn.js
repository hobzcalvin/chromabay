import{l as o,a as r}from"../chunks/BghYF3Wu.js";export{o as load_css,r as start};
