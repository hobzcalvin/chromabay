
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="412836e4-4667-5a0d-be58-702ff8e6dd9c")}catch(e){}}();
import{f as a,a as m}from"../chunks/BzCEQVYy.js";import{i as t}from"../chunks/DBMv0DXM.js";import{o as i}from"../chunks/BiZKHgRU.js";import{p as s,a as e}from"../chunks/COOuGChC.js";import{g as f}from"../chunks/RXAgNQR-.js";import{b as n}from"../chunks/DlZygV-o.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.n2C7AML0.js.map

//# debugId=412836e4-4667-5a0d-be58-702ff8e6dd9c
