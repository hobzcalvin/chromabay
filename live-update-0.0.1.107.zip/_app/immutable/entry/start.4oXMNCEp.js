import{l as o,a as r}from"../chunks/tNa3UNCw.js";export{o as load_css,r as start};
