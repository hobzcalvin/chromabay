import{l as o,a as r}from"../chunks/CkmpjWxN.js";export{o as load_css,r as start};
