import{l as o,a as r}from"../chunks/BH4P6jtx.js";export{o as load_css,r as start};
