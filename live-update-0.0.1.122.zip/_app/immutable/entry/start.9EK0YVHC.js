import{l as o,a as r}from"../chunks/OqD7CqGF.js";export{o as load_css,r as start};
