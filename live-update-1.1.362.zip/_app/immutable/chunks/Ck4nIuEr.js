
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f86920b5-e22b-5b9e-9152-3bbba1ad8998")}catch(e){}}();
var s;const t=((s=globalThis.__sveltekit_16upbte)==null?void 0:s.base)??"";var e;const a=((e=globalThis.__sveltekit_16upbte)==null?void 0:e.assets)??t;export{a,t as b};
//# sourceMappingURL=Ck4nIuEr.js.map

//# debugId=f86920b5-e22b-5b9e-9152-3bbba1ad8998
