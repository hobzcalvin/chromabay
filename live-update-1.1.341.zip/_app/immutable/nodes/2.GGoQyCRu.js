
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ed8a03f0-e484-5db4-b6c0-d11252035073")}catch(e){}}();
import{f as a,a as m}from"../chunks/BzCEQVYy.js";import{i as t}from"../chunks/DBMv0DXM.js";import{o as i}from"../chunks/BiZKHgRU.js";import{p as s,a as e}from"../chunks/COOuGChC.js";import{g as f}from"../chunks/JA2mHY0V.js";import{b as n}from"../chunks/0OY7oV1W.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.GGoQyCRu.js.map

//# debugId=ed8a03f0-e484-5db4-b6c0-d11252035073
