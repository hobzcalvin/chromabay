
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8b78b5ac-d715-5fb1-8a74-0b3e298e75d0")}catch(e){}}();
import{l as o,a as r}from"../chunks/JA2mHY0V.js";export{o as load_css,r as start};
//# sourceMappingURL=start.D1BxawTe.js.map

//# debugId=8b78b5ac-d715-5fb1-8a74-0b3e298e75d0
