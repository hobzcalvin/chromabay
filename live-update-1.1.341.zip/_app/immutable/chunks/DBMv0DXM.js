
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="db8f0043-2d26-5f79-9f90-7bb993f2a9f5")}catch(e){}}();
import{j as d,k as g,l as c,m as i,u as m,n as b,o as p,q as k,s as v,t as h}from"./COOuGChC.js";function x(n=!1){const s=d,e=s.l.u;if(!e)return;let f=()=>k(s.s);if(n){let o=0,t={};const _=v(()=>{let l=!1;const r=s.s;for(const a in r)r[a]!==t[a]&&(t[a]=r[a],l=!0);return l&&o++,o});f=()=>p(_)}e.b.length&&g(()=>{u(s,f),i(e.b)}),c(()=>{const o=m(()=>e.m.map(b));return()=>{for(const t of o)typeof t=="function"&&t()}}),e.a.length&&c(()=>{u(s,f),i(e.a)})}function u(n,s){if(n.l.s)for(const e of n.l.s)p(e);s()}h();export{x as i};
//# sourceMappingURL=DBMv0DXM.js.map

//# debugId=db8f0043-2d26-5f79-9f90-7bb993f2a9f5
