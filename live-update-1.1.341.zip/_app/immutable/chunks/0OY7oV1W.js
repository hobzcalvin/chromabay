
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8c8761eb-d4a4-586d-8825-1c5d4b84452f")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_17i7zk)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_17i7zk)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=0OY7oV1W.js.map

//# debugId=8c8761eb-d4a4-586d-8825-1c5d4b84452f
