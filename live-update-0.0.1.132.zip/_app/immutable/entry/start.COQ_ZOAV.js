import{l as o,a as r}from"../chunks/BiJrDo1L.js";export{o as load_css,r as start};
