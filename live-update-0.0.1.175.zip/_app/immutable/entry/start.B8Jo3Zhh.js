import{l as o,a as r}from"../chunks/DvI1P9tg.js";export{o as load_css,r as start};
