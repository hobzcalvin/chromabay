import{l as o,a as r}from"../chunks/CtZu7iMw.js";export{o as load_css,r as start};
