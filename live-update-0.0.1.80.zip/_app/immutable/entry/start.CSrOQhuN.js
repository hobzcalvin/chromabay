import{l as o,a as r}from"../chunks/BXPCqplM.js";export{o as load_css,r as start};
