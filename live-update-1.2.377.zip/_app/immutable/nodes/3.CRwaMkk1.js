
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e77a4892-3577-5b35-801f-06080c1d794b")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/DHsX9_my.js";import{p as t,o as r,a as s}from"../chunks/Bob6lHV9.js";import{g as p}from"../chunks/BEKUz6AF.js";import{b as i}from"../chunks/DiJeB0IC.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.CRwaMkk1.js.map

//# debugId=e77a4892-3577-5b35-801f-06080c1d794b
