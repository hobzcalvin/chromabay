
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d307c727-013a-555d-ae92-329e08310e0e")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as r}from"../chunks/DHsX9_my.js";import{p as t,o as m,a as i}from"../chunks/Bob6lHV9.js";import{f as s,a as e}from"../chunks/Dj6glD7V.js";import{g as f}from"../chunks/BEKUz6AF.js";import{b as n}from"../chunks/DiJeB0IC.js";var c=s("<p>Redirecting...</p>");function l(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),r();var a=c();e(o,a),i()}export{l as component};
//# sourceMappingURL=2.D_kRZVK8.js.map

//# debugId=d307c727-013a-555d-ae92-329e08310e0e
