import{l as o,a as r}from"../chunks/DHPHXiy4.js";export{o as load_css,r as start};
