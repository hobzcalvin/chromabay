import{_ as m}from"../chunks/BCX1Mrh_.js";export{m as component};
