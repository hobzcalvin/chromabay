
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e0a2c3b6-2be6-593a-97b2-6063fd731399")}catch(e){}}();
import{l as o,a as r}from"../chunks/_VgAFEDc.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DwuiDcke.js.map

//# debugId=e0a2c3b6-2be6-593a-97b2-6063fd731399
