import{l as o,a as r}from"../chunks/B1Fz042c.js";export{o as load_css,r as start};
