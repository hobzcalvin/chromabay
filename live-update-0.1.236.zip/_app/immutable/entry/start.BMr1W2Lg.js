import{l as o,a as r}from"../chunks/BnauDZoF.js";export{o as load_css,r as start};
