
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="fc04d386-caa2-5742-aa79-621269676e7f")}catch(e){}}();
import{l as o,a as r}from"../chunks/BBmmDb5N.js";export{o as load_css,r as start};
//# sourceMappingURL=start.Bzw_c-sE.js.map

//# debugId=fc04d386-caa2-5742-aa79-621269676e7f
