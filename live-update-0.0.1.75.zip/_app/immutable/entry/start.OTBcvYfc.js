import{l as o,a as r}from"../chunks/uBdFh4Fc.js";export{o as load_css,r as start};
