
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="bd295fbe-393c-54c7-a09b-423d6091099f")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_cjku2h)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_cjku2h)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=B_-6RCWO.js.map

//# debugId=bd295fbe-393c-54c7-a09b-423d6091099f
