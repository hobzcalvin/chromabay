import{l as o,a as r}from"../chunks/BoAFLxOo.js";export{o as load_css,r as start};
