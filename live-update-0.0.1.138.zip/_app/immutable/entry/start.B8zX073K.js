import{l as o,a as r}from"../chunks/DHIRY5lF.js";export{o as load_css,r as start};
