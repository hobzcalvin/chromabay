import{l as o,a as r}from"../chunks/BoS27VYa.js";export{o as load_css,r as start};
