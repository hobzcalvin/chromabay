import{l as o,a as r}from"../chunks/Cq7P1CzU.js";export{o as load_css,r as start};
