import{l as o,a as r}from"../chunks/BfK8-uGT.js";export{o as load_css,r as start};
