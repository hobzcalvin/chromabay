
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2c48e1d3-b2f6-5c91-a3d7-0442f05a0fe8")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_dueh15)==null?void 0:s.base)??"";var e;const t=((e=globalThis.__sveltekit_dueh15)==null?void 0:e.assets)??a;export{t as a,a as b};
//# sourceMappingURL=ulJFNQEb.js.map

//# debugId=2c48e1d3-b2f6-5c91-a3d7-0442f05a0fe8
