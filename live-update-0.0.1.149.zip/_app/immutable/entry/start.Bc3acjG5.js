import{l as o,a as r}from"../chunks/DX8ip0sW.js";export{o as load_css,r as start};
