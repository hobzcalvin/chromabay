import{l as o,a as r}from"../chunks/2mSn3ryT.js";export{o as load_css,r as start};
