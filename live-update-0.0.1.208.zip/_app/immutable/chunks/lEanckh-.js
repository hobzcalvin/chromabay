var s;const a=((s=globalThis.__sveltekit_ibq6ey)==null?void 0:s.base)??"";var e;const t=((e=globalThis.__sveltekit_ibq6ey)==null?void 0:e.assets)??a;export{t as a,a as b};
