import{l as o,a as r}from"../chunks/CsJLfXgX.js";export{o as load_css,r as start};
