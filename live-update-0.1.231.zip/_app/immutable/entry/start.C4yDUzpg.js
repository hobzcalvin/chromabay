import{l as o,a as r}from"../chunks/C5IdT_qB.js";export{o as load_css,r as start};
