import{l as o,a as r}from"../chunks/CyuaQ94K.js";export{o as load_css,r as start};
