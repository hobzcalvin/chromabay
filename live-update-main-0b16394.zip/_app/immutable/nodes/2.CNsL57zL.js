import{_ as m}from"../chunks/IajQCbiW.js";export{m as component};
