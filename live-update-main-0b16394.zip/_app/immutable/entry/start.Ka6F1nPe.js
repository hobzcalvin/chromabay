import{l as o,a as r}from"../chunks/BZO9cvua.js";export{o as load_css,r as start};
