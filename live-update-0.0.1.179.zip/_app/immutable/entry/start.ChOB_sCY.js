import{l as o,a as r}from"../chunks/C52BT5Ek.js";export{o as load_css,r as start};
