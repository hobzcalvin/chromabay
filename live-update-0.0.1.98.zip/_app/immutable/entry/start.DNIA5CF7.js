import{l as o,a as r}from"../chunks/B15NKiBf.js";export{o as load_css,r as start};
