
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="299e0088-a84c-54f2-b310-bf14a23fb74b")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_wfsagl)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_wfsagl)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=CpNxMM4-.js.map

//# debugId=299e0088-a84c-54f2-b310-bf14a23fb74b
