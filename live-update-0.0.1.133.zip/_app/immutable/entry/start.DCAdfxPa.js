import{l as o,a as r}from"../chunks/BR3A5Z10.js";export{o as load_css,r as start};
