import{l as o,a as r}from"../chunks/7T9hKsBr.js";export{o as load_css,r as start};
