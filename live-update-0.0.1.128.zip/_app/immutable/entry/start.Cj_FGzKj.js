import{l as o,a as r}from"../chunks/ByMmMjT5.js";export{o as load_css,r as start};
