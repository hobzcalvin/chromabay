var s;const e=((s=globalThis.__sveltekit_149l4fr)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_149l4fr)==null?void 0:a.assets)??e;export{t as a,e as b};
