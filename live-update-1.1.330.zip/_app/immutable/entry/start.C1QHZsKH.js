
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="327fa847-fa26-5a4d-abcf-c21f6f9f2325")}catch(e){}}();
import{l as o,a as r}from"../chunks/BGZYNqqL.js";export{o as load_css,r as start};
//# sourceMappingURL=start.C1QHZsKH.js.map

//# debugId=327fa847-fa26-5a4d-abcf-c21f6f9f2325
