
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d5400e56-de73-50c4-88a3-45819a8f0be4")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_im1pb3)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_im1pb3)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=D96RGB8d.js.map

//# debugId=d5400e56-de73-50c4-88a3-45819a8f0be4
