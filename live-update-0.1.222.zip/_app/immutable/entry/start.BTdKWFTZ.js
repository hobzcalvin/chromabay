import{l as o,a as r}from"../chunks/Bw5q8aOY.js";export{o as load_css,r as start};
