import{l as o,a as r}from"../chunks/C_X2MQb1.js";export{o as load_css,r as start};
