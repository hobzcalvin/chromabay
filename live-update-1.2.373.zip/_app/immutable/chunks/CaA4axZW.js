
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="cab0480f-9f1b-5345-8edd-206ffb7cc533")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_1fvwhlf)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1fvwhlf)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=CaA4axZW.js.map

//# debugId=cab0480f-9f1b-5345-8edd-206ffb7cc533
