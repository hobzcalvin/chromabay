
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e130a7c0-c5ea-56b9-a1f4-15c62a293e5e")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/CUcCykXD.js";import{o as a}from"../chunks/CHT_Wnc9.js";import{p as r,a as p}from"../chunks/Cd1DiQE4.js";import{g as s}from"../chunks/CMmahHy2.js";import{b as i}from"../chunks/CaA4axZW.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.BSQ1-rb0.js.map

//# debugId=e130a7c0-c5ea-56b9-a1f4-15c62a293e5e
