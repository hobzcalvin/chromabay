
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f34ae680-ec09-5976-a795-42d8f4c35d50")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CUcCykXD.js";import{o as m}from"../chunks/CHT_Wnc9.js";import{p as t,a as i}from"../chunks/Cd1DiQE4.js";import{f as s,a as e}from"../chunks/BZlP1PHN.js";import{g as f}from"../chunks/CMmahHy2.js";import{b as n}from"../chunks/CaA4axZW.js";var c=s("<p>Redirecting...</p>");function _(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),a();var r=c();e(o,r),i()}export{_ as component};
//# sourceMappingURL=2.BHK9uNSw.js.map

//# debugId=f34ae680-ec09-5976-a795-42d8f4c35d50
