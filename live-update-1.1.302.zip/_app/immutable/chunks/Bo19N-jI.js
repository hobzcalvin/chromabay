
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="22bc16e6-cd94-5270-b71c-c33fdc97af5b")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_1n66hvf)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1n66hvf)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=Bo19N-jI.js.map

//# debugId=22bc16e6-cd94-5270-b71c-c33fdc97af5b
