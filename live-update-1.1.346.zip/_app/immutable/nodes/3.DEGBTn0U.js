
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="859f549d-8767-5127-a518-9bf711a3c881")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/CG61vAxM.js";import{o as a}from"../chunks/DN4X5Wsx.js";import{p as r,a as p}from"../chunks/BkFBD7gE.js";import{g as s}from"../chunks/BcgRogi_.js";import{b as i}from"../chunks/CY3z9uGP.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.DEGBTn0U.js.map

//# debugId=859f549d-8767-5127-a518-9bf711a3c881
