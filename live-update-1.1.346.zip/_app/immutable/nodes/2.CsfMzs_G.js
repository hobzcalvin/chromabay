
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f8206895-56a3-566e-b7e4-13db38b79c88")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CG61vAxM.js";import{o as m}from"../chunks/DN4X5Wsx.js";import{p as t,a as i}from"../chunks/BkFBD7gE.js";import{f as s,a as e}from"../chunks/DftDsKR0.js";import{g as f}from"../chunks/BcgRogi_.js";import{b as n}from"../chunks/CY3z9uGP.js";var c=s("<p>Redirecting...</p>");function _(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),a();var r=c();e(o,r),i()}export{_ as component};
//# sourceMappingURL=2.CsfMzs_G.js.map

//# debugId=f8206895-56a3-566e-b7e4-13db38b79c88
