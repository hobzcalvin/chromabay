import{l as o,a as r}from"../chunks/CJ2Zo2Dy.js";export{o as load_css,r as start};
