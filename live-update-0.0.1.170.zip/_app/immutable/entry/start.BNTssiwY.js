import{l as o,a as r}from"../chunks/CqYQDO7j.js";export{o as load_css,r as start};
