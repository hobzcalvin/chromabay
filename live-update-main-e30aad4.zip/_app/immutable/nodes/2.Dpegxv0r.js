import{_ as m}from"../chunks/CO_pEeR_.js";export{m as component};
