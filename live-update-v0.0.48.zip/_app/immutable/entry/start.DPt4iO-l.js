import{l as o,a as r}from"../chunks/DHi5g9ib.js";export{o as load_css,r as start};
