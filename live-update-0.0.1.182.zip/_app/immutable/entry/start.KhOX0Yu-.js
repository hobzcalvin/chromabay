import{l as o,a as r}from"../chunks/CJX-Ia1A.js";export{o as load_css,r as start};
