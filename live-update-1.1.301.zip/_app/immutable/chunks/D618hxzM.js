
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d1b88488-1129-5cce-941f-08a6a085e5b6")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_1uq61em)==null?void 0:s.base)??"";var e;const t=((e=globalThis.__sveltekit_1uq61em)==null?void 0:e.assets)??a;export{t as a,a as b};
//# sourceMappingURL=D618hxzM.js.map

//# debugId=d1b88488-1129-5cce-941f-08a6a085e5b6
