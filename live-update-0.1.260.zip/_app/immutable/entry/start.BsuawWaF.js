import{l as o,a as r}from"../chunks/CuA6ptQ8.js";export{o as load_css,r as start};
