import{l as o,a as r}from"../chunks/DlukG6T4.js";export{o as load_css,r as start};
