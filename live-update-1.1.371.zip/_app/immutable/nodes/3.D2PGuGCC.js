
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b00eec5b-2ea9-54e5-b083-7124b3f0bd5d")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/CUcCykXD.js";import{o as a}from"../chunks/CHT_Wnc9.js";import{p as r,a as p}from"../chunks/Cd1DiQE4.js";import{g as s}from"../chunks/lvn3rdzP.js";import{b as i}from"../chunks/DgX-OZE7.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.D2PGuGCC.js.map

//# debugId=b00eec5b-2ea9-54e5-b083-7124b3f0bd5d
