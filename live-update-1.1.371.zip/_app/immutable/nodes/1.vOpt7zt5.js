
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="53858a5b-a62c-5dfc-8ee4-e3f52955f312")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as h}from"../chunks/CUcCykXD.js";import{p as g,aj as l,ak as v,a as d,al as e,am as o,an as _}from"../chunks/Cd1DiQE4.js";import{s as p}from"../chunks/Blzzelk6.js";import{f as x,a as k}from"../chunks/BZlP1PHN.js";import{s as $,p as m}from"../chunks/lvn3rdzP.js";const b={get error(){return m.error},get status(){return m.status}};$.updated.check;const i=b;var j=x("<h1> </h1> <p> </p>",1);function B(f,n){g(n,!1),h();var t=j(),r=l(t),c=e(r,!0);o(r);var a=_(r,2),u=e(a,!0);o(a),v(()=>{var s;p(c,i.status),p(u,(s=i.error)==null?void 0:s.message)}),k(f,t),d()}export{B as component};
//# sourceMappingURL=1.vOpt7zt5.js.map

//# debugId=53858a5b-a62c-5dfc-8ee4-e3f52955f312
