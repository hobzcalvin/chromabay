
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e784ecd7-94b1-54e5-b51e-f3916c37de0e")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_1p5o2jf)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1p5o2jf)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=DPu7pJOf.js.map

//# debugId=e784ecd7-94b1-54e5-b51e-f3916c37de0e
