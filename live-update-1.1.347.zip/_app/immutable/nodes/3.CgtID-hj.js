
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2711a16a-4f2d-5995-a133-91def3418a96")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/CG61vAxM.js";import{o as a}from"../chunks/DN4X5Wsx.js";import{p as r,a as p}from"../chunks/BkFBD7gE.js";import{g as s}from"../chunks/BphuVJIe.js";import{b as i}from"../chunks/D-4BARpV.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.CgtID-hj.js.map

//# debugId=2711a16a-4f2d-5995-a133-91def3418a96
