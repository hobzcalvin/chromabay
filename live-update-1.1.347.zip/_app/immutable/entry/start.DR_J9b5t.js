
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d384c525-6ebf-5b83-bb09-2397249a7d25")}catch(e){}}();
import{l as o,a as r}from"../chunks/BphuVJIe.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DR_J9b5t.js.map

//# debugId=d384c525-6ebf-5b83-bb09-2397249a7d25
