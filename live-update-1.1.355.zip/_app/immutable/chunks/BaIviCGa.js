
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b8fd91f0-8993-58b2-ad6c-6c7123e76fb8")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_19652ak)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_19652ak)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=BaIviCGa.js.map

//# debugId=b8fd91f0-8993-58b2-ad6c-6c7123e76fb8
