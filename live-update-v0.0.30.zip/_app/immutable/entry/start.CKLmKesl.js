import{l as o,a as r}from"../chunks/Do6-_qcw.js";export{o as load_css,r as start};
