import{l as o,a as r}from"../chunks/Y9JzVQHV.js";export{o as load_css,r as start};
