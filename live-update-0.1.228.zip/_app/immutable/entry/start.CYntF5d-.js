import{l as o,a as r}from"../chunks/z1wdqdSs.js";export{o as load_css,r as start};
