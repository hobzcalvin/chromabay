import{l as o,a as r}from"../chunks/DeqEcfvI.js";export{o as load_css,r as start};
