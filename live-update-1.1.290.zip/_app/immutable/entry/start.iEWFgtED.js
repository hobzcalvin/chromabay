import{l as o,a as r}from"../chunks/BME8Gp26.js";export{o as load_css,r as start};
