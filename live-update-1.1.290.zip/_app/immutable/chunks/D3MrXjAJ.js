var s;const e=((s=globalThis.__sveltekit_wx0l4v)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_wx0l4v)==null?void 0:a.assets)??e;export{t as a,e as b};
