import{l as o,a as r}from"../chunks/fEZdUCId.js";export{o as load_css,r as start};
