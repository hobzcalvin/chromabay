import{l as o,a as r}from"../chunks/CkPSC41O.js";export{o as load_css,r as start};
