
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ec1d20c1-c546-5df5-bc0a-e463e23e242b")}catch(e){}}();
import{l as o,a as r}from"../chunks/BwMgrF0y.js";export{o as load_css,r as start};
//# sourceMappingURL=start.C_I3aAuT.js.map

//# debugId=ec1d20c1-c546-5df5-bc0a-e463e23e242b
