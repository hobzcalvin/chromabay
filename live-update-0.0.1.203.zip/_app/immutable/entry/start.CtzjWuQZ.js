import{l as o,a as r}from"../chunks/Caw7mC6f.js";export{o as load_css,r as start};
