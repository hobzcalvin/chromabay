import{l as o,a as r}from"../chunks/C4dmU8G4.js";export{o as load_css,r as start};
