import{l as o,a as r}from"../chunks/DBqo6dz8.js";export{o as load_css,r as start};
