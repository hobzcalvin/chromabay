
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d19424b0-a21e-5b42-9c91-6cb745d9ce26")}catch(e){}}();
import{s as r}from"./mhBwoPQY.js";const e=()=>{const s=r;return{page:{subscribe:s.page.subscribe},navigating:{subscribe:s.navigating.subscribe},updated:s.updated}},a={subscribe(s){return e().page.subscribe(s)}},i={subscribe(s){return e().navigating.subscribe(s)}};export{i as n,a as p};
//# sourceMappingURL=CEPa13eu.js.map

//# debugId=d19424b0-a21e-5b42-9c91-6cb745d9ce26
