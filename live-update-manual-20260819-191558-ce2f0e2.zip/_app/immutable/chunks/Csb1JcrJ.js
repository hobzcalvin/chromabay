
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e788d7a9-f696-51a0-a2ec-ba5e4af7cf1c")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_1v5lq0p)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1v5lq0p)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=Csb1JcrJ.js.map

//# debugId=e788d7a9-f696-51a0-a2ec-ba5e4af7cf1c
