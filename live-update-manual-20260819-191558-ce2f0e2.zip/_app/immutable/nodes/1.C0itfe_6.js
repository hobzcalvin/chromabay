
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="30ce4bb5-c5d5-5d85-a93a-8c325b2a0daa")}catch(e){}}();
import{f as h,a as g}from"../chunks/e7ZU2XVh.js";import{i as l}from"../chunks/BtdIQ8g2.js";import{p as v,K as d,L as _,a as x,M as e,N as o,O as $}from"../chunks/CdHCThrA.js";import{s as p}from"../chunks/t9P6muLQ.js";import{s as k,p as m}from"../chunks/mhBwoPQY.js";const b={get error(){return m.error},get status(){return m.status}};k.updated.check;const i=b;var E=h("<h1> </h1> <p> </p>",1);function j(f,n){v(n,!1),l();var t=E(),r=d(t),c=e(r,!0);o(r);var a=$(r,2),u=e(a,!0);o(a),_(()=>{var s;p(c,i.status),p(u,(s=i.error)==null?void 0:s.message)}),g(f,t),x()}export{j as component};
//# sourceMappingURL=1.C0itfe_6.js.map

//# debugId=30ce4bb5-c5d5-5d85-a93a-8c325b2a0daa
