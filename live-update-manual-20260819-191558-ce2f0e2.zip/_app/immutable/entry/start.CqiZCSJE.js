
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b8e09ac4-feee-5fb3-a480-b847d8cac2d0")}catch(e){}}();
import{l as o,a as r}from"../chunks/mhBwoPQY.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CqiZCSJE.js.map

//# debugId=b8e09ac4-feee-5fb3-a480-b847d8cac2d0
