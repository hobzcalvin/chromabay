import{l as o,a as r}from"../chunks/CQFUh8_f.js";export{o as load_css,r as start};
