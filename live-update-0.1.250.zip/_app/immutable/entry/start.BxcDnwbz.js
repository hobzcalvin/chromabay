import{l as o,a as r}from"../chunks/Cj_y6vuJ.js";export{o as load_css,r as start};
