import{l as o,a as r}from"../chunks/CdB75RXM.js";export{o as load_css,r as start};
