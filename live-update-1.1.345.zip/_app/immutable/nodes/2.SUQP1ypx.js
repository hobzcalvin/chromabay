
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="9166f914-e418-5bce-8374-39227a766191")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/ChLFn2Di.js";import{o as m}from"../chunks/B3Ybdf9D.js";import{p as t,a as i}from"../chunks/BBkiyyPI.js";import{f as s,a as e}from"../chunks/BpyT9xn6.js";import{g as f}from"../chunks/DL0yFLB5.js";import{b as n}from"../chunks/CAdXBbaN.js";var c=s("<p>Redirecting...</p>");function _(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),a();var r=c();e(o,r),i()}export{_ as component};
//# sourceMappingURL=2.SUQP1ypx.js.map

//# debugId=9166f914-e418-5bce-8374-39227a766191
