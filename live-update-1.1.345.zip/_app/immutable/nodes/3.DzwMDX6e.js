
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="54a064d2-1d37-536d-94d3-ec0ec6da0e1d")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/ChLFn2Di.js";import{o as a}from"../chunks/B3Ybdf9D.js";import{p as r,a as p}from"../chunks/BBkiyyPI.js";import{g as s}from"../chunks/DL0yFLB5.js";import{b as i}from"../chunks/CAdXBbaN.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.DzwMDX6e.js.map

//# debugId=54a064d2-1d37-536d-94d3-ec0ec6da0e1d
