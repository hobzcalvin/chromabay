
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c619d29d-09be-50c7-832c-45cd251eb184")}catch(e){}}();
import{l as o,a as r}from"../chunks/DL0yFLB5.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CG7h-l5m.js.map

//# debugId=c619d29d-09be-50c7-832c-45cd251eb184
