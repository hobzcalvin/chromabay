
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e08cf636-2f4b-5ba0-959e-8de8fa90c522")}catch(e){}}();
import{l as o,a as r}from"../chunks/CSXq6tud.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BdJU9COK.js.map

//# debugId=e08cf636-2f4b-5ba0-959e-8de8fa90c522
