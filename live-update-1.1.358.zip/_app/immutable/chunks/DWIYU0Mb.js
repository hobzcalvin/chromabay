
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ec6b8b7b-9074-510a-8b5e-41199f04c7a2")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_ip29ys)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_ip29ys)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=DWIYU0Mb.js.map

//# debugId=ec6b8b7b-9074-510a-8b5e-41199f04c7a2
