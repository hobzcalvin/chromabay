import{l as o,a as r}from"../chunks/BrjsO6W4.js";export{o as load_css,r as start};
