import{l as o,a as r}from"../chunks/vjxN0DW-.js";export{o as load_css,r as start};
