import{l as o,a as r}from"../chunks/BHPt1xOR.js";export{o as load_css,r as start};
