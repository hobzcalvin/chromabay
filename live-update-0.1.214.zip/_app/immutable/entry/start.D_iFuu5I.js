import{l as o,a as r}from"../chunks/BJXW45hT.js";export{o as load_css,r as start};
