
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="bb5d0a2f-f7d2-50a9-8ff3-3f0d339bbd8a")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_l0czsg)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_l0czsg)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=BWAV2ghI.js.map

//# debugId=bb5d0a2f-f7d2-50a9-8ff3-3f0d339bbd8a
