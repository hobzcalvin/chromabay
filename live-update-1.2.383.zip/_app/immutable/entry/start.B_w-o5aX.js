
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="adee42b8-506e-549f-9833-6f4c9c8aff97")}catch(e){}}();
import{l as o,a as r}from"../chunks/Ct-_WZVr.js";export{o as load_css,r as start};
//# sourceMappingURL=start.B_w-o5aX.js.map

//# debugId=adee42b8-506e-549f-9833-6f4c9c8aff97
