
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="41cb250e-3392-5183-89a3-bf19779c61b7")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as r}from"../chunks/DHsX9_my.js";import{p as t,o as m,a as i}from"../chunks/Bob6lHV9.js";import{f as s,a as e}from"../chunks/Dj6glD7V.js";import{g as f}from"../chunks/Ct-_WZVr.js";import{b as n}from"../chunks/BWAV2ghI.js";var c=s("<p>Redirecting...</p>");function l(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),r();var a=c();e(o,a),i()}export{l as component};
//# sourceMappingURL=2.DN84ab-I.js.map

//# debugId=41cb250e-3392-5183-89a3-bf19779c61b7
