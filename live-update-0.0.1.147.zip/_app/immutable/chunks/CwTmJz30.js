var s;const e=((s=globalThis.__sveltekit_1mc1d5o)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1mc1d5o)==null?void 0:a.assets)??e;export{t as a,e as b};
