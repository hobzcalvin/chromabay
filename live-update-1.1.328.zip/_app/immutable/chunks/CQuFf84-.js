
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0565cc62-7276-5427-9d96-8c59d781fd60")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_18txtrm)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_18txtrm)==null?void 0:t.assets)??a;export{e as a,a as b};
//# sourceMappingURL=CQuFf84-.js.map

//# debugId=0565cc62-7276-5427-9d96-8c59d781fd60
