
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="586c84fc-ee78-51f5-87ac-243a74de2731")}catch(e){}}();
import{l as o,a as r}from"../chunks/e3N5AV2J.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DpRszVAz.js.map

//# debugId=586c84fc-ee78-51f5-87ac-243a74de2731
