
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="494ce00b-91aa-5e78-beb2-ac15cf43f164")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_xzxn93)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_xzxn93)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=B8aHw0SF.js.map

//# debugId=494ce00b-91aa-5e78-beb2-ac15cf43f164
