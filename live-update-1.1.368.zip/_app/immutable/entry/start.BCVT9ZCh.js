
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6dd8e16f-3406-57f2-9522-2f7c7b28b56d")}catch(e){}}();
import{l as o,a as r}from"../chunks/Bwa-2lDD.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BCVT9ZCh.js.map

//# debugId=6dd8e16f-3406-57f2-9522-2f7c7b28b56d
