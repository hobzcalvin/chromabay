
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0733a934-c81f-5d97-9609-8b5181dbf851")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/CUcCykXD.js";import{o as a}from"../chunks/CHT_Wnc9.js";import{p as r,a as p}from"../chunks/Cd1DiQE4.js";import{g as s}from"../chunks/Bwa-2lDD.js";import{b as i}from"../chunks/DwUpbG2P.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.B_nG6Cpn.js.map

//# debugId=0733a934-c81f-5d97-9609-8b5181dbf851
