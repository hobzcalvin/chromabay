
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="fc89d197-0f65-5031-a7b7-ccc7a588ea0c")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/CUcCykXD.js";import{o as a}from"../chunks/CHT_Wnc9.js";import{p as r,a as p}from"../chunks/Cd1DiQE4.js";import{g as s}from"../chunks/VA4xU4eu.js";import{b as i}from"../chunks/FnQJS4cW.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.nOK3NKZ3.js.map

//# debugId=fc89d197-0f65-5031-a7b7-ccc7a588ea0c
