
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="78475010-7a13-5c5b-b7f8-b6ddb185580f")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_j2vc5z)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_j2vc5z)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=FnQJS4cW.js.map

//# debugId=78475010-7a13-5c5b-b7f8-b6ddb185580f
