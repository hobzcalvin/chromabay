import{l as o,a as r}from"../chunks/BQ9d3NrC.js";export{o as load_css,r as start};
