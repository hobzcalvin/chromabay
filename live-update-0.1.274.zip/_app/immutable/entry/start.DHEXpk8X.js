import{l as o,a as r}from"../chunks/cDaS6aQk.js";export{o as load_css,r as start};
