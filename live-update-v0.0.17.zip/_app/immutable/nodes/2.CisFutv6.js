import{_ as m}from"../chunks/CEY7vLUc.js";export{m as component};
