
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="bec7acf0-c1d4-5b8c-b21f-4d648549d070")}catch(e){}}();
import{l as o,a as r}from"../chunks/B_nvLGdb.js";export{o as load_css,r as start};
//# sourceMappingURL=start.B0ZD29lo.js.map

//# debugId=bec7acf0-c1d4-5b8c-b21f-4d648549d070
