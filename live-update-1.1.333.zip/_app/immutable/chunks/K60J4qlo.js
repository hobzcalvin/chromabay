
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="7c7b71f3-fc7d-5138-9ced-ff2768f209f3")}catch(e){}}();
var s;const t=((s=globalThis.__sveltekit_5telkh)==null?void 0:s.base)??"";var e;const a=((e=globalThis.__sveltekit_5telkh)==null?void 0:e.assets)??t;export{a,t as b};
//# sourceMappingURL=K60J4qlo.js.map

//# debugId=7c7b71f3-fc7d-5138-9ced-ff2768f209f3
