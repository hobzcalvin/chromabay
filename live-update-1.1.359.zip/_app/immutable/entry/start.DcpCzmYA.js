
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b7f8f30a-2fb6-5129-bf30-14e0ac812840")}catch(e){}}();
import{l as o,a as r}from"../chunks/CPo4wP2a.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DcpCzmYA.js.map

//# debugId=b7f8f30a-2fb6-5129-bf30-14e0ac812840
