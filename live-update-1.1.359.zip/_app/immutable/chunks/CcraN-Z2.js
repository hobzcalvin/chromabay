
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c2742372-cd8e-5eb5-b6b9-6e87f9d5a3f9")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_1yiq7e8)==null?void 0:s.base)??"";var e;const t=((e=globalThis.__sveltekit_1yiq7e8)==null?void 0:e.assets)??a;export{t as a,a as b};
//# sourceMappingURL=CcraN-Z2.js.map

//# debugId=c2742372-cd8e-5eb5-b6b9-6e87f9d5a3f9
