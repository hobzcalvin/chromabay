import{l as o,a as r}from"../chunks/5jRCkiNx.js";export{o as load_css,r as start};
