import{l as o,a as r}from"../chunks/CdZ5BNKC.js";export{o as load_css,r as start};
