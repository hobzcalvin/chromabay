
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="02650515-9f05-51aa-9615-6c628549ca3f")}catch(e){}}();
import{f as a,a as m}from"../chunks/BzCEQVYy.js";import{i as t}from"../chunks/DBMv0DXM.js";import{o as i}from"../chunks/BiZKHgRU.js";import{p as s,a as e}from"../chunks/COOuGChC.js";import{g as f}from"../chunks/J2nJaaMy.js";import{b as n}from"../chunks/DX-H8KTN.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.BSDwwcpc.js.map

//# debugId=02650515-9f05-51aa-9615-6c628549ca3f
