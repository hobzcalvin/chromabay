
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="fd4d05d6-0b1c-5143-99ee-3fed235d83d9")}catch(e){}}();
import{f as a,a as m}from"../chunks/YSQa8gwn.js";import{i as t}from"../chunks/B4ueUsda.js";import{o as i}from"../chunks/iIm-hiKV.js";import{p as s,a as e}from"../chunks/DhkHA5kK.js";import{g as f}from"../chunks/C-9yBGDx.js";import{b as n}from"../chunks/B-McZWhW.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.BT0-cO8l.js.map

//# debugId=fd4d05d6-0b1c-5143-99ee-3fed235d83d9
