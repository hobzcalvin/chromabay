
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="36955cc2-882a-5c04-bca9-7c4334a01140")}catch(e){}}();
import{l as o,a as r}from"../chunks/C-9yBGDx.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CFhxuFoy.js.map

//# debugId=36955cc2-882a-5c04-bca9-7c4334a01140
