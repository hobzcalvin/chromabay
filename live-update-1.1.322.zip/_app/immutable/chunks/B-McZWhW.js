
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d636c08b-3fb2-5c68-917e-e591925ba651")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_1k1qwpr)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1k1qwpr)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=B-McZWhW.js.map

//# debugId=d636c08b-3fb2-5c68-917e-e591925ba651
