
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="1539e066-527c-58ef-b2c2-7002306ae1e6")}catch(e){}}();
import{l as o,a as r}from"../chunks/BIMr4fgH.js";export{o as load_css,r as start};
//# sourceMappingURL=start.xxLf7oc4.js.map

//# debugId=1539e066-527c-58ef-b2c2-7002306ae1e6
