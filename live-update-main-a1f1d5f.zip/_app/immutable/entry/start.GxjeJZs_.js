import{l as o,a as r}from"../chunks/Dp-1iMAF.js";export{o as load_css,r as start};
