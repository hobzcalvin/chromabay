import{l as o,a as r}from"../chunks/DwaR8Wro.js";export{o as load_css,r as start};
