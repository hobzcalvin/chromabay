import{l as o,a as r}from"../chunks/DN2-wnN7.js";export{o as load_css,r as start};
