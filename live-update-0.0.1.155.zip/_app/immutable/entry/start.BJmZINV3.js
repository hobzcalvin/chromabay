import{l as o,a as r}from"../chunks/DXs011xv.js";export{o as load_css,r as start};
