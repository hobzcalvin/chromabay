
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="40a1ffc6-8b1d-5acf-b10d-8b44cbb5ec4e")}catch(e){}}();
import{l as o,a as r}from"../chunks/BU3ZrwVM.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BIg1SXHB.js.map

//# debugId=40a1ffc6-8b1d-5acf-b10d-8b44cbb5ec4e
