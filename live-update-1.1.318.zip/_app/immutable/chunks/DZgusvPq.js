
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0c231882-de08-5b1a-bb5b-5dcffa3ab7a6")}catch(e){}}();
var s;const t=((s=globalThis.__sveltekit_eoxltg)==null?void 0:s.base)??"";var e;const a=((e=globalThis.__sveltekit_eoxltg)==null?void 0:e.assets)??t;export{a,t as b};
//# sourceMappingURL=DZgusvPq.js.map

//# debugId=0c231882-de08-5b1a-bb5b-5dcffa3ab7a6
