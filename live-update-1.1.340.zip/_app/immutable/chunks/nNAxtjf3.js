
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="10bd6bd9-eeb8-5c52-ac2f-d79312b5d76a")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_1xtvg9m)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_1xtvg9m)==null?void 0:t.assets)??a;export{e as a,a as b};
//# sourceMappingURL=nNAxtjf3.js.map

//# debugId=10bd6bd9-eeb8-5c52-ac2f-d79312b5d76a
