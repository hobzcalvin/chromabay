import{l as o,a as r}from"../chunks/CDCchJwf.js";export{o as load_css,r as start};
