import{l as o,a as r}from"../chunks/BBNLTbls.js";export{o as load_css,r as start};
