
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="752bb391-c6d4-5f87-a9ee-283f59a54b46")}catch(e){}}();
import{l as o,a as r}from"../chunks/Rcy8A1un.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CJCdBeUp.js.map

//# debugId=752bb391-c6d4-5f87-a9ee-283f59a54b46
