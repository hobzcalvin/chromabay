import{l as o,a as r}from"../chunks/6MfPLVus.js";export{o as load_css,r as start};
