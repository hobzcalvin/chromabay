
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="91e6670f-cdad-505f-8d13-141144a14b4e")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_4vyqij)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_4vyqij)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=BVdfhIc9.js.map

//# debugId=91e6670f-cdad-505f-8d13-141144a14b4e
