
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="885aced2-0eb8-51c0-86f2-43bf50ef4661")}catch(e){}}();
import{l as o,a as r}from"../chunks/X-1GtC6f.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BARJqH-Z.js.map

//# debugId=885aced2-0eb8-51c0-86f2-43bf50ef4661
