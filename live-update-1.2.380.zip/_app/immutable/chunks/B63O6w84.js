
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d2d96d93-1f8d-5f6f-97c0-0d4c18d41230")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_57d5ng)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_57d5ng)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=B63O6w84.js.map

//# debugId=d2d96d93-1f8d-5f6f-97c0-0d4c18d41230
