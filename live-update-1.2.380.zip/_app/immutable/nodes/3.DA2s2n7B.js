
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="637ab403-214d-5e45-9944-c2bf1cc3bf2d")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/DHsX9_my.js";import{p as t,o as r,a as s}from"../chunks/Bob6lHV9.js";import{g as p}from"../chunks/BG1yg6vL.js";import{b as i}from"../chunks/B63O6w84.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.DA2s2n7B.js.map

//# debugId=637ab403-214d-5e45-9944-c2bf1cc3bf2d
