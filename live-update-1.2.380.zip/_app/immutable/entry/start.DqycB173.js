
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="def8fcd9-5103-55dc-9943-efe64aa565c0")}catch(e){}}();
import{l as o,a as r}from"../chunks/BG1yg6vL.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DqycB173.js.map

//# debugId=def8fcd9-5103-55dc-9943-efe64aa565c0
