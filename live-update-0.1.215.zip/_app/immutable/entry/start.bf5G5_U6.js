import{l as o,a as r}from"../chunks/DuXWI36T.js";export{o as load_css,r as start};
