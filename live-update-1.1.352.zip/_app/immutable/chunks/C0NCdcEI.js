
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f1a78bfa-d7b2-57c3-bba2-b6a8d7d810f6")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_2j1c0t)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_2j1c0t)==null?void 0:t.assets)??a;export{e as a,a as b};
//# sourceMappingURL=C0NCdcEI.js.map

//# debugId=f1a78bfa-d7b2-57c3-bba2-b6a8d7d810f6
