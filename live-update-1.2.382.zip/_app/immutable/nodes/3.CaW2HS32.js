
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6b6fd44b-2036-5a8c-88a7-d8625dba1664")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/DHsX9_my.js";import{p as t,o as r,a as s}from"../chunks/Bob6lHV9.js";import{g as p}from"../chunks/CCfwafQ5.js";import{b as i}from"../chunks/DVvNi4E5.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.CaW2HS32.js.map

//# debugId=6b6fd44b-2036-5a8c-88a7-d8625dba1664
