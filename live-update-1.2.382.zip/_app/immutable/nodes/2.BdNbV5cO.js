
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ffeed4f7-cf89-5eab-8088-692524f486f1")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as r}from"../chunks/DHsX9_my.js";import{p as t,o as m,a as i}from"../chunks/Bob6lHV9.js";import{f as s,a as e}from"../chunks/Dj6glD7V.js";import{g as f}from"../chunks/CCfwafQ5.js";import{b as n}from"../chunks/DVvNi4E5.js";var c=s("<p>Redirecting...</p>");function l(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),r();var a=c();e(o,a),i()}export{l as component};
//# sourceMappingURL=2.BdNbV5cO.js.map

//# debugId=ffeed4f7-cf89-5eab-8088-692524f486f1
