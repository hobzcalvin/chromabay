
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="897b3651-6ada-5840-8fdd-c315b744b214")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as h}from"../chunks/DHsX9_my.js";import{p as g,_ as l,$ as v,a as _,a0 as e,a1 as o,a2 as d}from"../chunks/Bob6lHV9.js";import{s as p}from"../chunks/D1iU3r-e.js";import{f as x,a as $}from"../chunks/Dj6glD7V.js";import{s as k,p as m}from"../chunks/CCfwafQ5.js";const b={get error(){return m.error},get status(){return m.status}};k.updated.check;const i=b;var E=x("<h1> </h1> <p> </p>",1);function B(f,n){g(n,!1),h();var t=E(),r=l(t),c=e(r,!0);o(r);var a=d(r,2),u=e(a,!0);o(a),v(()=>{var s;p(c,i.status),p(u,(s=i.error)==null?void 0:s.message)}),$(f,t),_()}export{B as component};
//# sourceMappingURL=1.BRTGdNhN.js.map

//# debugId=897b3651-6ada-5840-8fdd-c315b744b214
