
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="51b8d597-2961-5e65-a834-793f298af773")}catch(e){}}();
import{l as o,a as r}from"../chunks/CCfwafQ5.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BlQe_94P.js.map

//# debugId=51b8d597-2961-5e65-a834-793f298af773
