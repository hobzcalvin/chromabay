
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b2f58616-8df9-5f84-8d8e-19c8866bd7e2")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_zprl26)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_zprl26)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=DVvNi4E5.js.map

//# debugId=b2f58616-8df9-5f84-8d8e-19c8866bd7e2
