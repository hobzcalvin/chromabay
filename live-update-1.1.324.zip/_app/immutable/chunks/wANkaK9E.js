
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="15173295-5ff5-560f-a59c-46dac27e86ee")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_1wa946s)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1wa946s)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=wANkaK9E.js.map

//# debugId=15173295-5ff5-560f-a59c-46dac27e86ee
