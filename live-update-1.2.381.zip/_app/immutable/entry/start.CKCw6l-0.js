
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="454ef95a-3007-5bbf-907b-3a8f46436b46")}catch(e){}}();
import{l as o,a as r}from"../chunks/DEpLV6YO.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CKCw6l-0.js.map

//# debugId=454ef95a-3007-5bbf-907b-3a8f46436b46
