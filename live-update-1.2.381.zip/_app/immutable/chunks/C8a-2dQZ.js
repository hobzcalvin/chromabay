
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="740281d8-e51b-5f5b-a0d5-873664a28341")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_101qhjy)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_101qhjy)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=C8a-2dQZ.js.map

//# debugId=740281d8-e51b-5f5b-a0d5-873664a28341
