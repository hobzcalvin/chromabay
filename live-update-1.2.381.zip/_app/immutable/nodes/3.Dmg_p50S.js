
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="16a80fee-53e7-5ba3-ac45-cda568d54eec")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/DHsX9_my.js";import{p as t,o as r,a as s}from"../chunks/Bob6lHV9.js";import{g as p}from"../chunks/DEpLV6YO.js";import{b as i}from"../chunks/C8a-2dQZ.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.Dmg_p50S.js.map

//# debugId=16a80fee-53e7-5ba3-ac45-cda568d54eec
