import{l as o,a as r}from"../chunks/Dm3fCoJK.js";export{o as load_css,r as start};
