import{l as o,a as r}from"../chunks/dCe-q_pQ.js";export{o as load_css,r as start};
