import{l as o,a as r}from"../chunks/Dnh90fHf.js";export{o as load_css,r as start};
