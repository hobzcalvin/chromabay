var s;const e=((s=globalThis.__sveltekit_bdwwnl)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_bdwwnl)==null?void 0:a.assets)??e;export{t as a,e as b};
