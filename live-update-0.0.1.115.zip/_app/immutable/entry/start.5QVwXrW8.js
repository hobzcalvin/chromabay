import{l as o,a as r}from"../chunks/CFbp31t7.js";export{o as load_css,r as start};
