import{l as o,a as r}from"../chunks/QM2tjEe6.js";export{o as load_css,r as start};
