import{l as o,a as r}from"../chunks/CRe5pkSS.js";export{o as load_css,r as start};
