
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="89f67052-3076-5d54-903c-40be8b3696f2")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_quwh8z)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_quwh8z)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=BC5r4Jbc.js.map

//# debugId=89f67052-3076-5d54-903c-40be8b3696f2
