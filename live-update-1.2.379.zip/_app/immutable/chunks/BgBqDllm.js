
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="16ea6cd9-c632-524b-8f20-9cb43db6800e")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_akf0po)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_akf0po)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=BgBqDllm.js.map

//# debugId=16ea6cd9-c632-524b-8f20-9cb43db6800e
