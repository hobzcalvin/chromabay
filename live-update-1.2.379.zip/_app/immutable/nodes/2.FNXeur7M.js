
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="9ca0f781-5503-5251-a8fb-746bb41e53fd")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as r}from"../chunks/DHsX9_my.js";import{p as t,o as m,a as i}from"../chunks/Bob6lHV9.js";import{f as s,a as e}from"../chunks/Dj6glD7V.js";import{g as f}from"../chunks/CzW2lOfY.js";import{b as n}from"../chunks/BgBqDllm.js";var c=s("<p>Redirecting...</p>");function l(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),r();var a=c();e(o,a),i()}export{l as component};
//# sourceMappingURL=2.FNXeur7M.js.map

//# debugId=9ca0f781-5503-5251-a8fb-746bb41e53fd
