
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="35a98fc9-4150-5b41-8d32-2f33e1a6a364")}catch(e){}}();
import{l as o,a as r}from"../chunks/CzW2lOfY.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DUGWOkap.js.map

//# debugId=35a98fc9-4150-5b41-8d32-2f33e1a6a364
