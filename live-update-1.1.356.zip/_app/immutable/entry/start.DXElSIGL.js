
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c04b0b3f-f824-5067-932a-5fc688dfbe46")}catch(e){}}();
import{l as o,a as r}from"../chunks/DiRbDJJ0.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DXElSIGL.js.map

//# debugId=c04b0b3f-f824-5067-932a-5fc688dfbe46
