
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="75e87511-33ef-5d17-9625-5cc40e3b74b2")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_htcr2t)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_htcr2t)==null?void 0:t.assets)??a;export{e as a,a as b};
//# sourceMappingURL=kRzUvq9H.js.map

//# debugId=75e87511-33ef-5d17-9625-5cc40e3b74b2
