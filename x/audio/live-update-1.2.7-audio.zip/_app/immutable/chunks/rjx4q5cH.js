
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5929873c-41ac-57be-959b-c7fbf4096add")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_18ddntg)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_18ddntg)==null?void 0:t.assets)??a;export{e as a,a as b};
//# sourceMappingURL=rjx4q5cH.js.map

//# debugId=5929873c-41ac-57be-959b-c7fbf4096add
