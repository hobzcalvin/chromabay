
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="a41e75a9-24ba-5ad1-8b36-a314bff79dc7")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as r}from"../chunks/CHHvBerd.js";import{p as t,o as m,a as i}from"../chunks/HeQaF-Yi.js";import{f as s,a as e}from"../chunks/krmJ43ty.js";import{g as f}from"../chunks/GGEUQAZX.js";import{b as n}from"../chunks/rjx4q5cH.js";var c=s("<p>Redirecting...</p>");function l(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),r();var a=c();e(o,a),i()}export{l as component};
//# sourceMappingURL=2.e3YBGC0n.js.map

//# debugId=a41e75a9-24ba-5ad1-8b36-a314bff79dc7
