
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5cdce616-ec04-5679-bacb-6ad1a5e87e3f")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CHHvBerd.js";import{p as t,o as r,a as s}from"../chunks/HeQaF-Yi.js";import{g as p}from"../chunks/GGEUQAZX.js";import{b as i}from"../chunks/rjx4q5cH.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.erhus3lN.js.map

//# debugId=5cdce616-ec04-5679-bacb-6ad1a5e87e3f
