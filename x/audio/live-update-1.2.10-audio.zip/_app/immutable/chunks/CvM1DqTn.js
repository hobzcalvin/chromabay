
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e1a219c6-8e04-5835-88dc-529fc59e488c")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_mom6xl)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_mom6xl)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=CvM1DqTn.js.map

//# debugId=e1a219c6-8e04-5835-88dc-529fc59e488c
