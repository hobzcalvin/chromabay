
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2c6f1047-7ae8-5c16-8d89-0168dda284c6")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CHHvBerd.js";import{p as t,o as r,a as s}from"../chunks/HeQaF-Yi.js";import{g as p}from"../chunks/CCF7876k.js";import{b as i}from"../chunks/CvM1DqTn.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.BCIi15wO.js.map

//# debugId=2c6f1047-7ae8-5c16-8d89-0168dda284c6
