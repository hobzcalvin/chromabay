
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="42fa6b36-5408-54f2-999b-7452b699d806")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_3r0rqu)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_3r0rqu)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=DuVUcWbH.js.map

//# debugId=42fa6b36-5408-54f2-999b-7452b699d806
