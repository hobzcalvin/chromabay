
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e950a6ce-1f3f-5e37-bf11-983a95417d11")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CHHvBerd.js";import{p as t,o as r,a as s}from"../chunks/HeQaF-Yi.js";import{g as p}from"../chunks/CDdig_8S.js";import{b as i}from"../chunks/DuVUcWbH.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.Ca4K4l_V.js.map

//# debugId=e950a6ce-1f3f-5e37-bf11-983a95417d11
