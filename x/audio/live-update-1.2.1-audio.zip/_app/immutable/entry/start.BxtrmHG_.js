
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f0af912e-40c8-5381-837c-0f2701ac0a03")}catch(e){}}();
import{l as o,a as r}from"../chunks/DEdqKlJN.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BxtrmHG_.js.map

//# debugId=f0af912e-40c8-5381-837c-0f2701ac0a03
