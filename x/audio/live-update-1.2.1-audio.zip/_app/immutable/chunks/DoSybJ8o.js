
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5a760b59-e3bc-5016-9c99-c9380c00321b")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_3lktm9)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_3lktm9)==null?void 0:t.assets)??a;export{e as a,a as b};
//# sourceMappingURL=DoSybJ8o.js.map

//# debugId=5a760b59-e3bc-5016-9c99-c9380c00321b
