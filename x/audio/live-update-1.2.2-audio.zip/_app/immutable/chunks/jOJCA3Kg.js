
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="fd650b20-ea96-5f64-bae2-4acd935447d7")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_wzvy44)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_wzvy44)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=jOJCA3Kg.js.map

//# debugId=fd650b20-ea96-5f64-bae2-4acd935447d7
