
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="892dcc65-8bfc-5c0b-bd2b-424c4e2fa6c2")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CHHvBerd.js";import{p as t,o as r,a as s}from"../chunks/HeQaF-Yi.js";import{g as p}from"../chunks/qFvQpzxB.js";import{b as i}from"../chunks/jOJCA3Kg.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.DdoZtkPg.js.map

//# debugId=892dcc65-8bfc-5c0b-bd2b-424c4e2fa6c2
