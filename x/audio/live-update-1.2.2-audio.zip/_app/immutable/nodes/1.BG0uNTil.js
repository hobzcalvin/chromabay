
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0413a181-af71-5677-9939-f20e8a1dfd3c")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as h}from"../chunks/CHHvBerd.js";import{p as g,_ as l,$ as v,a as _,a0 as e,a1 as o,a2 as d}from"../chunks/HeQaF-Yi.js";import{s as p}from"../chunks/CFpjCb1O.js";import{f as x,a as $}from"../chunks/krmJ43ty.js";import{s as k,p as m}from"../chunks/qFvQpzxB.js";const b={get error(){return m.error},get status(){return m.status}};k.updated.check;const i=b;var E=x("<h1> </h1> <p> </p>",1);function B(f,n){g(n,!1),h();var t=E(),r=l(t),c=e(r,!0);o(r);var a=d(r,2),u=e(a,!0);o(a),v(()=>{var s;p(c,i.status),p(u,(s=i.error)==null?void 0:s.message)}),$(f,t),_()}export{B as component};
//# sourceMappingURL=1.BG0uNTil.js.map

//# debugId=0413a181-af71-5677-9939-f20e8a1dfd3c
