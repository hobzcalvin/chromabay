
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="12d12029-8395-5300-865f-064799debb6d")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as r}from"../chunks/CHHvBerd.js";import{p as t,o as m,a as i}from"../chunks/HeQaF-Yi.js";import{f as s,a as e}from"../chunks/krmJ43ty.js";import{g as f}from"../chunks/qFvQpzxB.js";import{b as n}from"../chunks/jOJCA3Kg.js";var c=s("<p>Redirecting...</p>");function l(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),r();var a=c();e(o,a),i()}export{l as component};
//# sourceMappingURL=2.XFCGWT5E.js.map

//# debugId=12d12029-8395-5300-865f-064799debb6d
