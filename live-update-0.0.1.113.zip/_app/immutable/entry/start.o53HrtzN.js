import{l as o,a as r}from"../chunks/DyPtRTfS.js";export{o as load_css,r as start};
