import{l as o,a as r}from"../chunks/B5lJ5F7l.js";export{o as load_css,r as start};
