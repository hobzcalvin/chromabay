import{l as o,a as r}from"../chunks/DCk-Rhrk.js";export{o as load_css,r as start};
