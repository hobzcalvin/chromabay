
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f2a2bfde-3dbb-51fe-836c-b3531cdda80b")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_2o5z5l)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_2o5z5l)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=BmprKXbW.js.map

//# debugId=f2a2bfde-3dbb-51fe-836c-b3531cdda80b
