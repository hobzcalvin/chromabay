
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0f77b65a-9fad-5dc8-9eb0-aeff11579941")}catch(e){}}();
import{l as o,a as r}from"../chunks/-HOwgfjW.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BtqYjpFW.js.map

//# debugId=0f77b65a-9fad-5dc8-9eb0-aeff11579941
