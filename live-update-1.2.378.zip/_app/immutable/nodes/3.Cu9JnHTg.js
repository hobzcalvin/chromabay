
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="649dfaf8-1029-5ffa-b603-9518d84fac2a")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/DHsX9_my.js";import{p as t,o as r,a as s}from"../chunks/Bob6lHV9.js";import{g as p}from"../chunks/Cx7oS1jr.js";import{b as i}from"../chunks/1NQRdog5.js";function $(e,o){t(o,!1),r(()=>{p(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),a(),s()}export{$ as component};
//# sourceMappingURL=3.Cu9JnHTg.js.map

//# debugId=649dfaf8-1029-5ffa-b603-9518d84fac2a
