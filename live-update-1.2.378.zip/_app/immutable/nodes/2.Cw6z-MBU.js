
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8f770ca6-bc2e-5696-95e2-034c6430eba4")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as r}from"../chunks/DHsX9_my.js";import{p as t,o as m,a as i}from"../chunks/Bob6lHV9.js";import{f as s,a as e}from"../chunks/Dj6glD7V.js";import{g as f}from"../chunks/Cx7oS1jr.js";import{b as n}from"../chunks/1NQRdog5.js";var c=s("<p>Redirecting...</p>");function l(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),r();var a=c();e(o,a),i()}export{l as component};
//# sourceMappingURL=2.Cw6z-MBU.js.map

//# debugId=8f770ca6-bc2e-5696-95e2-034c6430eba4
