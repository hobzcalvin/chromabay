
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="566e700b-6406-5ee9-9a0a-72e4c1314950")}catch(e){}}();
import{l as o,a as r}from"../chunks/Cx7oS1jr.js";export{o as load_css,r as start};
//# sourceMappingURL=start.U2Wtn35r.js.map

//# debugId=566e700b-6406-5ee9-9a0a-72e4c1314950
