
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="251c72e4-c98a-5c51-ab6b-2a06034c7cbc")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_1hdp40l)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_1hdp40l)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=BoQxSgXg.js.map

//# debugId=251c72e4-c98a-5c51-ab6b-2a06034c7cbc
