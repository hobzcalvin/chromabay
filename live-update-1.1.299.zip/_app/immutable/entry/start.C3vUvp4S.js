
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8648f68b-2e63-5985-bd74-72b64fbc2eb4")}catch(e){}}();
import{l as o,a as r}from"../chunks/B8ycng3Z.js";export{o as load_css,r as start};
//# sourceMappingURL=start.C3vUvp4S.js.map

//# debugId=8648f68b-2e63-5985-bd74-72b64fbc2eb4
