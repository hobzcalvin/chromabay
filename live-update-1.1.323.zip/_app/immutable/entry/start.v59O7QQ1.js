
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="cc77e99e-a6b0-52fa-8280-2b0f698494e6")}catch(e){}}();
import{l as o,a as r}from"../chunks/BgqJ-P1M.js";export{o as load_css,r as start};
//# sourceMappingURL=start.v59O7QQ1.js.map

//# debugId=cc77e99e-a6b0-52fa-8280-2b0f698494e6
