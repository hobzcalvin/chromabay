
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="78e50f2a-1515-5e12-847e-e903fa2cd347")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_oscqka)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_oscqka)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=C4_GwrFy.js.map

//# debugId=78e50f2a-1515-5e12-847e-e903fa2cd347
