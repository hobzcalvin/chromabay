
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="03167c52-3046-53c0-9b2f-cebfa6c59fb3")}catch(e){}}();
import{f as a,a as m}from"../chunks/YSQa8gwn.js";import{i as t}from"../chunks/B4ueUsda.js";import{o as i}from"../chunks/iIm-hiKV.js";import{p as s,a as e}from"../chunks/DhkHA5kK.js";import{g as f}from"../chunks/BgqJ-P1M.js";import{b as n}from"../chunks/C4_GwrFy.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.VRjEr-zB.js.map

//# debugId=03167c52-3046-53c0-9b2f-cebfa6c59fb3
