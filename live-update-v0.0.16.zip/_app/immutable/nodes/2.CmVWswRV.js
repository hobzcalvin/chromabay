import{_ as m}from"../chunks/DE5UhdMW.js";export{m as component};
