import{l as o,a as r}from"../chunks/Bme28kt7.js";export{o as load_css,r as start};
