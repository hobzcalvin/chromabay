
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="15442cc2-2efc-587e-a950-6c903638b4c8")}catch(e){}}();
import{f as a,a as m}from"../chunks/Rohqeugo.js";import{i as t}from"../chunks/D4AgwrkV.js";import{o as i}from"../chunks/DDVIaiys.js";import{p as s,a as e}from"../chunks/DMuXAWdp.js";import{g as f}from"../chunks/DHGrWnLq.js";import{b as n}from"../chunks/BSjqnjC5.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.HXKZ-7Xb.js.map

//# debugId=15442cc2-2efc-587e-a950-6c903638b4c8
