
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="af8c8790-90db-587b-97dc-e5dda07be56d")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_1s3dltn)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_1s3dltn)==null?void 0:t.assets)??a;export{e as a,a as b};
//# sourceMappingURL=BSjqnjC5.js.map

//# debugId=af8c8790-90db-587b-97dc-e5dda07be56d
