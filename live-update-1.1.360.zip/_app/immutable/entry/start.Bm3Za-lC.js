
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="55751cf6-5316-5e4d-8244-05a22309862e")}catch(e){}}();
import{l as o,a as r}from"../chunks/B2ibXqGR.js";export{o as load_css,r as start};
//# sourceMappingURL=start.Bm3Za-lC.js.map

//# debugId=55751cf6-5316-5e4d-8244-05a22309862e
