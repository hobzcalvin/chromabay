
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c3b68336-4e15-5e19-a7ee-7ef9d83468fa")}catch(e){}}();
var s;const a=((s=globalThis.__sveltekit_znt4gp)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_znt4gp)==null?void 0:t.assets)??a;export{e as a,a as b};
//# sourceMappingURL=dZUehXJ0.js.map

//# debugId=c3b68336-4e15-5e19-a7ee-7ef9d83468fa
