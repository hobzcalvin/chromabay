import{l as o,a as r}from"../chunks/DE0PCg4s.js";export{o as load_css,r as start};
