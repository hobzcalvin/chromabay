
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e8ee97f4-96e4-5be1-aa2f-d67c52dca92b")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/CG61vAxM.js";import{o as a}from"../chunks/DN4X5Wsx.js";import{p as r,a as p}from"../chunks/BkFBD7gE.js";import{g as s}from"../chunks/CTg1mpni.js";import{b as i}from"../chunks/BmHfT93h.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.DJRc76D4.js.map

//# debugId=e8ee97f4-96e4-5be1-aa2f-d67c52dca92b
