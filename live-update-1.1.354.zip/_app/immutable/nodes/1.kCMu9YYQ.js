
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="9eac63e0-3ccb-53ef-8eb5-dba43329a797")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as h}from"../chunks/CG61vAxM.js";import{p as g,C as l,D as v,a as d,F as e,G as o,H as _}from"../chunks/BkFBD7gE.js";import{s as p}from"../chunks/CKeIotaR.js";import{f as x,a as $}from"../chunks/DftDsKR0.js";import{s as k,p as m}from"../chunks/CTg1mpni.js";const b={get error(){return m.error},get status(){return m.status}};k.updated.check;const i=b;var C=x("<h1> </h1> <p> </p>",1);function q(f,n){g(n,!1),h();var t=C(),r=l(t),c=e(r,!0);o(r);var a=_(r,2),u=e(a,!0);o(a),v(()=>{var s;p(c,i.status),p(u,(s=i.error)==null?void 0:s.message)}),$(f,t),d()}export{q as component};
//# sourceMappingURL=1.kCMu9YYQ.js.map

//# debugId=9eac63e0-3ccb-53ef-8eb5-dba43329a797
