
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="84c1f31b-f1c5-5318-b27a-b400c3256945")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/CG61vAxM.js";import{o as m}from"../chunks/DN4X5Wsx.js";import{p as t,a as i}from"../chunks/BkFBD7gE.js";import{f as s,a as e}from"../chunks/DftDsKR0.js";import{g as f}from"../chunks/CTg1mpni.js";import{b as n}from"../chunks/BmHfT93h.js";var c=s("<p>Redirecting...</p>");function _(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),a();var r=c();e(o,r),i()}export{_ as component};
//# sourceMappingURL=2.BoZmvO18.js.map

//# debugId=84c1f31b-f1c5-5318-b27a-b400c3256945
