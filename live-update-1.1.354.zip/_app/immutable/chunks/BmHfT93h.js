
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ac4d4966-6584-5ecc-b6e4-8a34365da26b")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_e89a0q)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_e89a0q)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=BmHfT93h.js.map

//# debugId=ac4d4966-6584-5ecc-b6e4-8a34365da26b
