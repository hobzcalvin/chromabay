import{l as o,a as r}from"../chunks/BT9QSotr.js";export{o as load_css,r as start};
