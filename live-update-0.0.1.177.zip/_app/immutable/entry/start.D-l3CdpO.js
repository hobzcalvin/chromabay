import{l as o,a as r}from"../chunks/3ODzya26.js";export{o as load_css,r as start};
