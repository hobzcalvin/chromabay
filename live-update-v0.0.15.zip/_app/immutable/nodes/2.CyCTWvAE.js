import{_ as m}from"../chunks/BhBSLMP8.js";export{m as component};
