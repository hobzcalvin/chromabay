import{l as o,a as r}from"../chunks/C1O47VFJ.js";export{o as load_css,r as start};
