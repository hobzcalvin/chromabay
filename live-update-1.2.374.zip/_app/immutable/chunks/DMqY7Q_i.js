
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8a8545a5-7966-5542-aed2-d8e1bf48b739")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_rcbg7n)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_rcbg7n)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=DMqY7Q_i.js.map

//# debugId=8a8545a5-7966-5542-aed2-d8e1bf48b739
