
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2fea389d-caae-50e4-a470-5443c8221276")}catch(e){}}();
import{l as o,a as r}from"../chunks/BNFsdbxj.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BtJ-bOp-.js.map

//# debugId=2fea389d-caae-50e4-a470-5443c8221276
