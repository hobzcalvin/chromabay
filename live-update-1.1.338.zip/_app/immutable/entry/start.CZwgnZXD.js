
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e628e9e8-0730-5f1a-b19e-28b661e573a0")}catch(e){}}();
import{l as o,a as r}from"../chunks/BVVwb9SI.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CZwgnZXD.js.map

//# debugId=e628e9e8-0730-5f1a-b19e-28b661e573a0
