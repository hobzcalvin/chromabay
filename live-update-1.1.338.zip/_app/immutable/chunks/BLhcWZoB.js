
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f07a8def-42fb-5ddb-a537-8ffaf600b966")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_19mnnn7)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_19mnnn7)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=BLhcWZoB.js.map

//# debugId=f07a8def-42fb-5ddb-a537-8ffaf600b966
