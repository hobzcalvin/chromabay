
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="3d2df9ec-6c6c-5201-bbc8-b1b63f54e84d")}catch(e){}}();
import{f as a,a as m}from"../chunks/e7ZU2XVh.js";import{i as t}from"../chunks/BtdIQ8g2.js";import{o as i}from"../chunks/hQfVTg2t.js";import{p as s,a as e}from"../chunks/CdHCThrA.js";import{g as f}from"../chunks/BSU2D66C.js";import{b as n}from"../chunks/_vf7eHLq.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.DQuowEK2.js.map

//# debugId=3d2df9ec-6c6c-5201-bbc8-b1b63f54e84d
