
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c1c8f295-6413-5731-a0be-ba3eeeb8d273")}catch(e){}}();
import{l as o,a as r}from"../chunks/BSU2D66C.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CoA91rjY.js.map

//# debugId=c1c8f295-6413-5731-a0be-ba3eeeb8d273
