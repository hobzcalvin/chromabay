import{l as o,a as r}from"../chunks/BP6dAO3p.js";export{o as load_css,r as start};
