import{l as o,a as r}from"../chunks/DZdcslZ-.js";export{o as load_css,r as start};
