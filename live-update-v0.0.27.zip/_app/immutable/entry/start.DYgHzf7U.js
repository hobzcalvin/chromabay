import{l as o,a as r}from"../chunks/8DHHByCr.js";export{o as load_css,r as start};
