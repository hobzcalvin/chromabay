import{l as o,a as r}from"../chunks/Dr0G5nXp.js";export{o as load_css,r as start};
