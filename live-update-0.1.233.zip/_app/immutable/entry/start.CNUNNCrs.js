import{l as o,a as r}from"../chunks/BWBUC_Zw.js";export{o as load_css,r as start};
