import{l as o,a as r}from"../chunks/D55hvmx4.js";export{o as load_css,r as start};
