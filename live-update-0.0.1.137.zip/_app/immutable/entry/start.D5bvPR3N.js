import{l as o,a as r}from"../chunks/gsZyr40l.js";export{o as load_css,r as start};
