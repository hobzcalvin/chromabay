
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="98514789-3535-5c3c-955f-429636f2222e")}catch(e){}}();
import{l as o,a as r}from"../chunks/C--wbyPQ.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CTW_M5bD.js.map

//# debugId=98514789-3535-5c3c-955f-429636f2222e
