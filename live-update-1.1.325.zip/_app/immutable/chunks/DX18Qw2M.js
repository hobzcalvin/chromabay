
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f6538d3c-5a8e-547d-b65e-765e87bfa23a")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_vdqk8i)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_vdqk8i)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=DX18Qw2M.js.map

//# debugId=f6538d3c-5a8e-547d-b65e-765e87bfa23a
