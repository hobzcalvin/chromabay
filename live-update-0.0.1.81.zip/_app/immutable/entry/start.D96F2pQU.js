import{l as o,a as r}from"../chunks/B9we-K6L.js";export{o as load_css,r as start};
