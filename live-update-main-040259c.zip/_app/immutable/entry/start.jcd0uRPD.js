import{l as o,a as r}from"../chunks/CcQaFmhO.js";export{o as load_css,r as start};
