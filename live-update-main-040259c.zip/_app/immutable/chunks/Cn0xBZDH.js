import{y as a}from"./BjvdeGKV.js";a();
