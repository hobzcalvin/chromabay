
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="bbaee0ad-d746-5b97-b45a-bb6b18354c95")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as t}from"../chunks/d2Ei34wb.js";import{o as a}from"../chunks/Wu5cKY3K.js";import{p as r,a as p}from"../chunks/BTWnyPQm.js";import{g as s}from"../chunks/VHHchLpt.js";import{b as i}from"../chunks/BjQVJcHO.js";function g(m,o){r(o,!1),a(()=>{s(`${i}/settings${location.search}${location.hash}`,{replaceState:!0})}),t(),p()}export{g as component};
//# sourceMappingURL=3.CQCBMaTj.js.map

//# debugId=bbaee0ad-d746-5b97-b45a-bb6b18354c95
