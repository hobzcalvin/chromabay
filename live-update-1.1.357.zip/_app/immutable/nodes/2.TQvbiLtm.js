
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="821bb864-0423-559f-99ae-3441759161c0")}catch(e){}}();
import"../chunks/CWj6FrbW.js";import{i as a}from"../chunks/d2Ei34wb.js";import{o as m}from"../chunks/Wu5cKY3K.js";import{p as t,a as i}from"../chunks/BTWnyPQm.js";import{f as s,a as e}from"../chunks/WZeTerMx.js";import{g as f}from"../chunks/VHHchLpt.js";import{b as n}from"../chunks/BjQVJcHO.js";var c=s("<p>Redirecting...</p>");function _(o,p){t(p,!1),m(()=>{f(`${n}/devices`)}),a();var r=c();e(o,r),i()}export{_ as component};
//# sourceMappingURL=2.TQvbiLtm.js.map

//# debugId=821bb864-0423-559f-99ae-3441759161c0
