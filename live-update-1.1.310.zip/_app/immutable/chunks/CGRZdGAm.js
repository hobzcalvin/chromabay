
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5874f30c-e3af-5987-9c34-ce7a398ea726")}catch(e){}}();
import{s as r}from"./BRX3MHS3.js";const e=()=>{const s=r;return{page:{subscribe:s.page.subscribe},navigating:{subscribe:s.navigating.subscribe},updated:s.updated}},a={subscribe(s){return e().page.subscribe(s)}},i={subscribe(s){return e().navigating.subscribe(s)}};export{i as n,a as p};
//# sourceMappingURL=CGRZdGAm.js.map

//# debugId=5874f30c-e3af-5987-9c34-ce7a398ea726
