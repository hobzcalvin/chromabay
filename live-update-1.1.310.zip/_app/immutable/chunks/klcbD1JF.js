
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="58fdbf15-f759-5a55-8410-63717584b586")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_ix8zvh)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_ix8zvh)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=klcbD1JF.js.map

//# debugId=58fdbf15-f759-5a55-8410-63717584b586
