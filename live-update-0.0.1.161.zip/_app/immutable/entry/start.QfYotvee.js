import{l as o,a as r}from"../chunks/BNDaOB48.js";export{o as load_css,r as start};
