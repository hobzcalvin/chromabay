import{l as o,a as r}from"../chunks/BkxuS09q.js";export{o as load_css,r as start};
