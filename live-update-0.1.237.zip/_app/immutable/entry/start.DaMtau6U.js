import{l as o,a as r}from"../chunks/2blSin1k.js";export{o as load_css,r as start};
