import{l as o,a as r}from"../chunks/3ZkWP_Ts.js";export{o as load_css,r as start};
