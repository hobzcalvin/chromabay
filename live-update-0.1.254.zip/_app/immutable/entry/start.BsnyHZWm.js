import{l as o,a as r}from"../chunks/O6IJ4kns.js";export{o as load_css,r as start};
