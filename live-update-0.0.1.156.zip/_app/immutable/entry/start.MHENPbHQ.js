import{l as o,a as r}from"../chunks/Bk4GdEfW.js";export{o as load_css,r as start};
