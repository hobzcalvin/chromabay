import{l as o,a as r}from"../chunks/C-16YjML.js";export{o as load_css,r as start};
