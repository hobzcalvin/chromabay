
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="a7a53c29-59f1-5bb7-b518-4d7993d42b82")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_w9i5zu)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_w9i5zu)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=KnbkZd4b.js.map

//# debugId=a7a53c29-59f1-5bb7-b518-4d7993d42b82
