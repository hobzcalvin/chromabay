
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="aad7c0d4-4b94-5f86-9230-7a188b9ae7f2")}catch(e){}}();
import{f as h,a as g}from"../chunks/Rohqeugo.js";import{i as l}from"../chunks/D4AgwrkV.js";import{p as v,K as d,L as _,a as x,M as e,N as o,O as $}from"../chunks/DMuXAWdp.js";import{s as p}from"../chunks/D3gYmNYF.js";import{s as k,p as m}from"../chunks/DeWaw_WK.js";const b={get error(){return m.error},get status(){return m.status}};k.updated.check;const i=b;var E=h("<h1> </h1> <p> </p>",1);function j(f,n){v(n,!1),l();var t=E(),r=d(t),c=e(r,!0);o(r);var a=$(r,2),u=e(a,!0);o(a),_(()=>{var s;p(c,i.status),p(u,(s=i.error)==null?void 0:s.message)}),g(f,t),x()}export{j as component};
//# sourceMappingURL=1.CAHb7wM5.js.map

//# debugId=aad7c0d4-4b94-5f86-9230-7a188b9ae7f2
