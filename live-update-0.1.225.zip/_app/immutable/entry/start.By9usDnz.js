import{l as o,a as r}from"../chunks/DCmI4ZEA.js";export{o as load_css,r as start};
