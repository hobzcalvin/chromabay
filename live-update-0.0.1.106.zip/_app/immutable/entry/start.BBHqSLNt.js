import{l as o,a as r}from"../chunks/BJ0G09BN.js";export{o as load_css,r as start};
