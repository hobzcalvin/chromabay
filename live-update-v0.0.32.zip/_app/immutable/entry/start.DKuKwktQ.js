import{l as o,a as r}from"../chunks/DOBK110_.js";export{o as load_css,r as start};
