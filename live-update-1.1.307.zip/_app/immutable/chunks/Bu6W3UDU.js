
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="81f047e8-4325-53dc-936b-54af9270a01c")}catch(e){}}();
var s;const e=((s=globalThis.__sveltekit_xzgjlm)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_xzgjlm)==null?void 0:a.assets)??e;export{t as a,e as b};
//# sourceMappingURL=Bu6W3UDU.js.map

//# debugId=81f047e8-4325-53dc-936b-54af9270a01c
