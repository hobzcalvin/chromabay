
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c0b031a9-8ba2-563e-8428-ad91510ccac8")}catch(e){}}();
import{s as r}from"./DeJtpcVZ.js";const e=()=>{const s=r;return{page:{subscribe:s.page.subscribe},navigating:{subscribe:s.navigating.subscribe},updated:s.updated}},a={subscribe(s){return e().page.subscribe(s)}},i={subscribe(s){return e().navigating.subscribe(s)}};export{i as n,a as p};
//# sourceMappingURL=Bz58mrjf.js.map

//# debugId=c0b031a9-8ba2-563e-8428-ad91510ccac8
