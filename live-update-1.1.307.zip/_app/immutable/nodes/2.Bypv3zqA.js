
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8a97c8d5-db19-5658-8b53-4671000c8850")}catch(e){}}();
import{f as a,a as m}from"../chunks/e7ZU2XVh.js";import{i as t}from"../chunks/BtdIQ8g2.js";import{o as i}from"../chunks/hQfVTg2t.js";import{p as s,a as e}from"../chunks/CdHCThrA.js";import{g as f}from"../chunks/DeJtpcVZ.js";import{b as n}from"../chunks/Bu6W3UDU.js";var c=a("<p>Redirecting...</p>");function l(o,p){s(p,!1),i(()=>{f(`${n}/devices`)}),t();var r=c();m(o,r),e()}export{l as component};
//# sourceMappingURL=2.Bypv3zqA.js.map

//# debugId=8a97c8d5-db19-5658-8b53-4671000c8850
