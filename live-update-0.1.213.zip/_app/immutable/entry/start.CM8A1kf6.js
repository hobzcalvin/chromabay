import{l as o,a as r}from"../chunks/7E8fiL6r.js";export{o as load_css,r as start};
