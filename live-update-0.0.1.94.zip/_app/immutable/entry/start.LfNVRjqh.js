import{l as o,a as r}from"../chunks/BzDVOkim.js";export{o as load_css,r as start};
