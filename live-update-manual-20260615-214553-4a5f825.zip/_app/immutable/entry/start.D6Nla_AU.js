import{l as o,a as r}from"../chunks/CwnA8Q0a.js";export{o as load_css,r as start};
